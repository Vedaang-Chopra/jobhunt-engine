# Browser and Tool Usage Rules

## Interface preference
1. Reliable structured MCP/API/tool when available.
2. Playwright/browser-control MCP for dynamic/interactive websites.
3. Manual browser interaction only when necessary.

## Browser-control rule
When real browser interaction is required, prefer Hermes' Playwright/browser-control MCP. Do not solve research by continuously spawning Chrome tabs.

## Tab discipline
- reuse tabs;
- keep a small working set;
- avoid one permanent tab per job/person;
- reuse LinkedIn/company search tabs;
- close temporary tabs when done;
- avoid duplicates;
- clean browser state after completing a task.

Typical working set: one LinkedIn search tab, one company-careers tab, one job/application detail tab, temporary tabs only when necessary.

## Task-oriented browsing
Every browser session needs a defined objective: e.g. find NVIDIA roles, inspect 15 referral candidates, search recent hiring posts, verify 10 jobs, or fill one application. Complete the goal, persist results, then clean up.

## Authentication
If login is required, ask the user to authenticate directly in the browser and reuse authenticated sessions/autofill/extensions. Never ask to store passwords, OTPs, recovery codes, or secrets in project files/chat.

## Failure handling
If a site blocks automation or requires login, record the failure, request authentication when needed, continue with other useful sources, and never mark the source as successfully searched when it was not.
