# LinkedIn Hiring Post Search Rules

## Principle
LinkedIn posts are a first-class job-discovery channel, separate from LinkedIn Jobs.

Search recent posts for signals such as:
- we're hiring
- join my team
- hiring research engineers
- looking for ML/AI engineers
- new roles on my team
- building the team
- hiring for AI/ML/research

Use semantic variations; do not depend on exact phrases.

## For every relevant post capture
Poster, poster role, company, team/org if identifiable, post URL, recency, roles mentioned, application URL, whether poster is hiring manager/recruiter/founder/team member, connection degree, alumni/mutual/shared context, role fit, recommended next action.

## Priority boost
A recent hiring post from a hiring manager, team lead, relevant engineer/researcher, or team recruiter can be more valuable than a generic job-board listing because it creates a direct human path.

## Outreach
Do not automatically send. Prepare the appropriate response or connection strategy unless standing permission exists.
