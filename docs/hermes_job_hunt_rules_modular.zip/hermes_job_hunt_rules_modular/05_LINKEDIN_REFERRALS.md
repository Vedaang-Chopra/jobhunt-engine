# LinkedIn Referral and Connection Research Rules

## Goal
Given a company or role, find people who provide a credible path to referral, introduction, hiring-team insight, or useful conversation. Do not dump the first LinkedIn employees returned.

## Search hierarchy
1. 1st-degree connections.
2. 2nd-degree connections.
3. 3rd-degree connections.
4. Georgia Tech alumni.
5. Former coworkers/shared employers.
6. Mutual connections.
7. People in the relevant technical domain.
8. People on the relevant team.
9. Hiring managers/team leads.
10. Recruiters tied to the organization.
11. People with strong shared research/project context.

## Geography
For U.S. roles, prefer U.S.-based people when all else is equal. Strong contacts in India, Toronto, Europe, or elsewhere remain valuable if relationship/alumni/mutual/internal referral strength is better.

## Individual profile inspection is mandatory
For every serious contact candidate:
- inspect the profile;
- confirm current company/role/team;
- identify shared context;
- assess relevance to the target role;
- decide whether referral, introduction, informational outreach, or no outreach is appropriate;
- record why the person is worth contacting.

LinkedIn ranking alone is not evidence.

## Ranking signals
Connection degree, alumni link, mutuals, shared employers, technical/domain overlap, same team/org, hiring-manager/recruiter relevance, geographic relevance, relationship strength, ability to refer, and quality of the reason for outreach.

## Required record fields
Name, LinkedIn URL, company, title, location, degree, relevant team, alumni/shared affiliation, mutuals, shared context, target job IDs, reason to contact, recommended ask, referral likelihood, outreach priority, email/status/source, outreach status, last verified.
